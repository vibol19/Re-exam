package com.example.entity;

import java.util.*;
import jakarta.persistence.*;
import jakarta.transaction.Transactional;
import lombok.Data;

import java.util.Scanner;

@Entity
@Transactional
@Data
@Table
public class Province {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)

    private Long provinceId;
    private String provinceName;
    private String provinceNameInKhmer;


    @OneToOne(cascade = CascadeType.ALL)
    private Province province;
}
class Provinces{
    private int provincesId;
    private String provincesName;
    private String provincesNameInKhmer;

    Provinces(int provincesId, String provincesName, String provincesNameInKhmer){
        this.provincesId = provincesId;
        this.provincesName = provincesName;
        this.provincesNameInKhmer = provincesNameInKhmer;
    }
    public int getProvincesId(){
        return provincesId;
    }
    public String getProvincesName(){
        return provincesName;
    }
    public String getProvincesNameInKhmer(){
        return provincesNameInKhmer;
    }
    }
    class CRUD{
        public static void main(String[] args) {
            List<Provinces> c = new ArrayList<Provinces>();
            Scanner s = new Scanner(System.in);
            Scanner s1 = new Scanner(System.in);
            int ch;
            do{
                System.out.println("1. INSERT");
                System.out.println("2. UPDATE");
                System.out.println("3. DELETE");
                System.out.println("4. SELECT");
                ch = s.nextInt();

                switch (ch){
                    case 1:
                        System.out.println("Enter Province ID");
                        int provinceId = s.nextInt();
                        System.out.println("Enter Province ID");
                        String provinceName = s1.nextLine();
                        System.out.println("Enter Province ID");
                        String  provinceNameInKhmer = s1.nextLine();
                        c.add(new Provinces(provinceId, provinceName, provinceNameInKhmer));

                    break;
                    case 2:
                        System.out.println("---------------------");
                        Iterator<Provinces> i = c.iterator();
                        while (i.hasNext()){
                            Provinces e = i.next();
                            System.out.println(e);
                        }
                        System.out.println("--------------------------");
                    break;
                    case 3:
                        boolean found = false;
                        System.out.println("Enter Province to Search");
                        int provincesId = s.nextInt();
                        System.out.println("-----------------------");
                        i = c.iterator();
                        while (i.hasNext()){
                            Provinces e = i.next();
                            if (e.getProvincesId() == provincesId){
                                System.out.println(e);
                                found = true;
                            }
                        }
                        if(!found){
                            System.out.println("Record not found");
                        }
                        System.out.println("----------------");
                    break;
                    case 4:
                        found = false;
                        System.out.println("Enter Province to Delete");
                        provincesId = s.nextInt();
                        System.out.println("-----------------------");
                        i = c.iterator();
                        while (i.hasNext()){
                            Provinces e = i.next();
                            if (e.getProvincesId() == provincesId){
                                i.remove();
                                found = true;
                            }
                        }
                        if(!found){
                            System.out.println("Record not found");
                        }
                        else{
                            System.out.println("Record is deleted successfully");
                        }
                        System.out.println("----------------");
                    break;
                    case 5:
                        found = false;
                        System.out.println("Enter Province to Update");
                        provincesId = s.nextInt();
                        System.out.println("-----------------------");
                        ListIterator<Provinces> li = c.listIterator();
                        while (li.hasNext()){
                            Provinces e = li.next();
                            if (e.getProvincesId() == provincesId){
                                System.out.println("Enter the new province name");
                                provinceName = s1.nextLine();

                                System.out.println("Enter the new province name in khmer");
                                provinceNameInKhmer = s1.nextLine();

                                li.set(new Provinces(provincesId,provinceName, provinceNameInKhmer));
                                found = true;
                            }
                        }
                        if(!found){
                            System.out.println("Record not found");
                        }
                        else{
                            System.out.println("Record is updated successfully");
                        }
                        System.out.println("----------------");
                        break;
                }
            }while (ch!=0);
        }
    }

