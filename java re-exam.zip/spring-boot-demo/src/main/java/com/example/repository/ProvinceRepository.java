package com.example.repository;


import com.example.dto.ProvinceResponse;
import com.example.entity.Province;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;


public interface ProvinceRepository extends JpaRepository<Province,Integer>{
    @Query("select new com.example.dto.ProvinceResponse(c.provinceName , p.provinceNameInKhmer) from Province c join c.provinceId")

    public List<ProvinceResponse> getJoinInformation();
}
