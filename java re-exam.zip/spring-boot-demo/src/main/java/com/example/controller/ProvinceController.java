package com.example.controller;

import com.example.dto.ProvinceRequest;
import com.example.dto.ProvinceResponse;
import com.example.entity.Province;
import com.example.repository.DistrictRepository;
import com.example.repository.ProvinceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProvinceController {
    @Autowired
    private ProvinceRepository provinceRepository;
    @Autowired
    private DistrictRepository districtRepository;
    @PostMapping("/saveProvince")
    public Province saveProvince(@RequestBody ProvinceRequest request){
        return provinceRepository.save(request.getProvince());
    }
    @GetMapping("/findAllProvinces")
    public List<Province> findAllProvince(){
        return provinceRepository.findAll();
    }

}
