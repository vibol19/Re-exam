package com.example.UserController;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
    @RequestMapping("/")
    public String hello()
    {
        System.out.println("function hello()");
        return "Hello spring boot";
    }

    @RequestMapping("/user-id/{user-id}/username/{username}")
    public String findUserByIdUserName(
            @PathVariable("user-id") Long id,
            @PathVariable String username
    ){
        System.out.println("user id: " + id);
        System.out.println("username: " + username);
        return "Hello World";
    }

//    public String




}