package com.example.service;

import com.example.dto.ProvinceRequest;
import com.example.entity.Province;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProvinceService {
    @Autowired
    private ProvinceRepository repository;

    public Province saveProvince(ProvinceRequest){
        Province province = Province.build(1,ProvinceRequest.getProvinceName(),ProvinceRequest.getProvinceNameInKhmer() );
        return repository.save(province);

    }
    public List<Province> getAllProvince(){
        return repository.findAll();
    }
    public Province getProvince(int id){
        return repository.findByProvinceId(id);
    }
}
