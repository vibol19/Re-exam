package com.example.controller;

import com.example.dto.ProvinceRequest;
import com.example.entity.Province;
import com.example.service.ProvinceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/{spring-boot-demo}/")
public class ProvinceController {

    @Autowired
    private ProvinceService service;
    private String getProvince(){
        return getProvince();
    }
    @PostMapping("/create")
    public ResponseEntity<Province> saveProvince(@RequestBody ProvinceRequest provinceRequest){
        return new ResponseEntity<>(service.saveProvince(provinceRequest),HttpStatus.CREATED);

    }
    @GetMapping("/fetchAll")
    public ResponseEntity<List<Province>>getAllProvince(){
        return ResponseEntity.ok(service.getAllProvince());

    }
    @GetMapping("{id}")
    public ResponseEntity<Province>getProvince(@PathVariable int id){
        return ResponseEntity.ok(service.getProvince(id));
    }

}
