package com.example.dto;

import com.example.entity.Province;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class ProvinceRequest {
    private String provinceName;
    private String provinceNameInKhmer;
}
